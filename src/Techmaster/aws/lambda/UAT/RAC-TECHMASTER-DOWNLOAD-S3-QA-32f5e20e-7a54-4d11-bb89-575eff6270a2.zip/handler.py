import pymysql
import json
import logging
import boto3
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.message import EmailMessage
import os
import csv
from datetime import datetime
from sercret_manager import secretManager
secretDit = secretManager.get_value(os.getenv("AWS_SECRETS_MYSQL"))

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class DatabaseConnection:
    def __init__(self):
        self.host = secretDit["host"]
        self.username = secretDit["username"]
        self.password = secretDit["password"]
        self.db_name = secretDit["dbname"]
        self.port = int(secretDit["port"])
        
        # self.host = os.environ.get("DB_HOST")
        # self.username = os.environ.get("DB_USER")
        # self.password = os.environ.get("DB_PASSWORD")
        # self.db_name = os.environ.get("DB_NAME")
        # self.port = int(os.environ.get("DB_PORT"))

    def connect(self):
        try:
            connection = pymysql.connect(
                host=self.host,
                user=self.username,
                password=self.password,
                port=self.port,
                db=self.db_name,
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
            return connection
        except Exception as e:
            raise Exception(f"Error connecting to the database: {str(e)}")

def is_log_id_exists(connection, log_id):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM RAC_FS_TM_LOGS WHERE tm_log_id = %s", (log_id,))
            result = cursor.fetchone()
            return result
    except Exception as e:
        return None

def update_lambda_status(connection, log_id, status):
    try:
        with connection.cursor() as cursor:
            cursor.execute("UPDATE RAC_FS_TM_LOGS SET lambda_status = %s WHERE tm_log_id = %s", (status, log_id))
            connection.commit()
            return True
    except Exception as e:
        logger.error(f"Error updating lambda status: {str(e)}")
        return False
    
def update_record(connection, table_name, update_data, condition, log_id):
    try:
        with connection.cursor() as cursor:
            sql = f"UPDATE {table_name} SET "
            set_clause = ", ".join([f"{column} = %s" for column in update_data.keys()])
            sql += set_clause
            sql += f" WHERE {condition}"

            values = list(update_data.values())
            values.append(log_id)

            # Execute the SQL statement
            cursor.execute(sql, values)

            # Commit the transaction
            connection.commit()

            return True
    except Exception as e:
        logger.error(f"Error updating record in {table_name}: {str(e)}")
        return False
    
def fetch_records_from_database(connection):
    query = """
        SELECT 
            tab_fs_emp.EMPLOYEE_ID,
            tab_hr_tm.EMPLOYEE_NAME,
            tab_fs_emp.MANAGER_ID,
            tab_hr_tm.EMAIL,
            tab_hr_tm_1.EMPLOYEE_NAME as MANAGER_NAME,
            tab_hr_tm.RESOURCE_NUMBER,
            tab_fs_emp.LOCATION_CODE,
            tab_area.AREA_SHORT_NAME,
            tab_region.REGION_NAME,
            tab_team_type.TEAM_TYPE_NAME,
            tab_fs_emp.MANAGER_FLAG,
            tab_fs_emp.WORK_SHIFT,
            tab_fs_emp.ON_CALL,
            tab_fs_emp.ON_SITE,
            tab_fs_emp.DEDICATED,
            tab_fs_emp.DEDICATED_TO,
            tab_fs_emp.SERVICE_ADVANTAGE,
            tab_fs_emp.FS_STATUS,
            tab_fs_emp.SERVICE_START_DATE,
            tab_fs_emp.SERVICE_END_DATE,
            tab_fs_emp.RECORD_COMPLETE,
            tab_fs_emp.ADMIN_NOTES,
            tab_job_code.JOB_TITLE,
            tab_job_code.JOB_ADP_CODE,
            tab_job_code.JOB_TYPE,
            NULL CHANGE_NOTES,
            NULL CHANGE_EFFECTIVE_DATE,
            NULL REVIEW_DATE,
            NULL UPDARE_FLAG
        FROM
            RAC_FS_TM_EMPLOYEE_DTLS AS tab_fs_emp
                INNER JOIN
            RAC_HR_TM_EMPLOYEE_DTLS AS tab_hr_tm ON tab_fs_emp.EMPLOYEE_ID = tab_hr_tm.EMPLOYEE_ID
                INNER JOIN
            RAC_HR_TM_EMPLOYEE_DTLS AS tab_hr_tm_1 ON tab_fs_emp.MANAGER_ID = tab_hr_tm_1.EMPLOYEE_ID
                LEFT JOIN
            RAC_FS_TM_AREA AS tab_area ON tab_area.AREA_ID = tab_fs_emp.AREA_ID
                LEFT JOIN
            RAC_FS_TM_REGION AS tab_region ON tab_region.REGION_ID = tab_area.REGION_ID
                LEFT JOIN
            RAC_FS_TM_TEAM_TYPE AS tab_team_type ON tab_team_type.TEAM_TYPE_ID = tab_fs_emp.TEAM_TYPE_ID
				LEFT JOIN
            RAC_FS_TM_JOB_CODE as tab_job_code on tab_job_code.JOB_ID = tab_fs_emp.JOB_ID
    """

    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            records = cursor.fetchall()
        return records
    except Exception as e:
        raise Exception(f"Error fetching records from the database: {str(e)}")
    

def fetch_location_records_from_database(connection):
    query = """
        SELECT 
            LOC_ID, 
            LOCATION_CODE, 
            DESCRIPTION, 
            ZIP_CODE,
            INACTIVE_DATE
        FROM
            RAC_FS_TM_LOC
    """

    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            records = cursor.fetchall()
        return records
    except Exception as e:
        raise Exception(f"Error fetching records from the database: {str(e)}")

def format_datetime(dt):
    if dt is not None:
        return dt.strftime('%m-%d-%Y')
    return ''

def create_csv_from_records(records):
    csv_file = '/tmp/exported_data.csv'
    fieldnames = ['Change Note', 'Change Effective Date (mm/dd/yyyy)', 'Region' ,'Area Short', 'Location Code', 'Manager Name', 
                  'Manager Employee ID', 'Employee ID', 'Resource Number', 'Employee Name', 'Employee Email', 
                  'Job Title', 'Job Type', 'Job ADP Code' , 'Team Type',
                  'Work Shift (1st, 2nd, 3rd)', 'On Call', 'On Site', 'Dedicated', 'Dedicated To',
                  'Service Advantage', 'FS Status', 'Service Start Date (mm/dd/yyyy)', 'Service End Date (mm/dd/yyyy)', 'Record Complete',
                  'Manager Flag', 'Admin Notes', 'Review Date (mm/dd/yyyy)', 'Update Flag']

    with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for record in records:
            writer.writerow({
                'Change Note': record.get('CHANGE_NOTES', ''),
                'Change Effective Date (mm/dd/yyyy)': format_datetime(record.get('CHANGE_EFFECTIVE_DATE')),
                'Region': record.get('REGION_NAME', ''),
                'Area Short': record.get('AREA_SHORT_NAME', ''),
                'Location Code': record.get('LOCATION_CODE', ''),
                'Manager Name': record.get('MANAGER_NAME', ''),
                'Manager Employee ID': record.get('MANAGER_ID', ''),
                'Employee ID': record.get('EMPLOYEE_ID', ''),
                'Resource Number': record.get('RESOURCE_NUMBER', ''),
                'Employee Name': record.get('EMPLOYEE_NAME', ''),
                'Employee Email': record.get('EMAIL', ''),
                'Job Title': record.get('JOB_TITLE', ''),
                'Job Type': record.get('JOB_TYPE', ''),
                'Job ADP Code': record.get('JOB_ADP_CODE', ''),
                'Team Type': record.get('TEAM_TYPE_NAME', ''),
                'Work Shift (1st, 2nd, 3rd)': record.get('WORK_SHIFT', ''),
                'On Call': record.get('ON_CALL', ''),
                'On Site': record.get('ON_SITE', ''),
                'Dedicated': record.get('DEDICATED', ''),
                'Dedicated To': record.get('DEDICATED_TO', ''),
                'Service Advantage': record.get('SERVICE_ADVANTAGE', ''),
                'FS Status': record.get('FS_STATUS', ''),
                'Service Start Date (mm/dd/yyyy)': format_datetime(record.get('SERVICE_START_DATE')),
                'Service End Date (mm/dd/yyyy)': format_datetime(record.get('SERVICE_END_DATE')),
                'Record Complete': record.get('RECORD_COMPLETE', ''),
                'Manager Flag': record.get('MANAGER_FLAG', ''),
                'Admin Notes': record.get('ADMIN_NOTES', ''),
                'Review Date (mm/dd/yyyy)': format_datetime(record.get('REVIEW_DATE')),
                'Update Flag': record.get('UPDATE_FLAG',''),
            })

    return csv_file

def create_csv_from_location_records(records):
    csv_file = '/tmp/location_data.csv'
    fieldnames = ['LOC ID', 'LOCATION CODE', 'DESCRIPTION', 'ZIP CODE', 'INACTIVE DATE']

    with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for record in records:
            writer.writerow({
                'LOC ID': record.get('LOC_ID', ''),
                'LOCATION CODE': record.get('LOCATION_CODE', ''),
                'DESCRIPTION': record.get('DESCRIPTION', ''),
                'ZIP CODE': record.get('ZIP_CODE', ''),
                'INACTIVE DATE': format_datetime(record.get('INACTIVE_DATE', ''))
            })

    return csv_file

def upload_csv_to_s3(csv_file, s3_bucket, s3_key):
    s3_client = boto3.client('s3')
    try:
        s3_client.upload_file(csv_file, s3_bucket, s3_key)
        logger.info(f"Uploaded {csv_file} to S3 bucket {s3_bucket} with key {s3_key}")
    except Exception as e:
        logger.error(f"Error uploading {csv_file} to S3: {str(e)}")


def generate_presigned_url(s3_bucket, s3_key):
    s3_client = boto3.client('s3')
    url = s3_client.generate_presigned_url('get_object', Params={'Bucket': s3_bucket, 'Key': s3_key}, ExpiresIn=43200)
    return url

def send_email(recipient_email, download_link):
    try:
        smtp_server = os.environ.get("SMTP_SERVER")
        from_address = os.environ.get("FROM_ADDRESS")

        if not smtp_server or not from_address:
            raise ValueError("SMTP_SERVER or FROM_ADDRESS are not set.")

        subject = "Tech Master Data Export"
        body = f"Dear All,<br><br>Please download Bulk export sheet using below link and it's valid for 12 hours.<br><br><table><tr>"
        
        body+=f"<tr><td><a href={download_link}>Download</a></td></tr>"
        body+= f"<tr></table><br>NOTE : This is a system generated email,***No reply required***<br><br>Thank you"
        msg = EmailMessage()
        msg.set_content(body)
        msg.add_alternative(body, subtype='html')
        msg['Subject'] = subject
        msg['From'] = from_address
        msg['To'] = recipient_email
        
        logger.info(recipient_email)
        smtp_client = smtplib.SMTP(smtp_server)
        smtp_client.sendmail(from_address, recipient_email, msg.as_string())
        smtp_client.quit()

        logger.info("Email sent successfully")

        return "Email Sent"

    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return "Email Error"

def lambda_handler(event, context):
    try:
        logger.info(f"Request payload is: {event}")
        log_id = event.get("log_id")

        db_connection = DatabaseConnection()
        conn = db_connection.connect()

        log_exists = is_log_id_exists(conn, log_id)

        if log_exists:
            with conn:
                request_type = log_exists["TYPE"]
                if log_exists["LAMBDA_STATUS"] == "pending":
                    current_status = "STARTED"
                    if update_lambda_status(conn, log_id, current_status):
                        # Use the current timestamp for the file name
                        timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
                        if request_type == "location":
                            records = fetch_location_records_from_database(conn)
                            file_name_format = f"{timestamp}_techmaster_location.csv"
                        else:
                            records = fetch_records_from_database(conn)
                            file_name_format = f"{timestamp}_techmaster_v1.csv"
                        if records:
                            
                            csv_filename = f"/tmp/{file_name_format}"

                            if request_type == "location":
                                csv_file_path = create_csv_from_location_records(records)
                            else:
                                csv_file_path = create_csv_from_records(records)

                            s3_bucket = os.environ.get("S3_BUCKET")
                            s3_export_path = os.environ.get("S3_EXPORT_PATH")
                            s3_key = f"{s3_export_path}/{file_name_format}"
                            
                            upload_csv_to_s3(csv_file_path, s3_bucket, s3_key)

                            # Generate a presigned URL for the uploaded file
                            presigned_url = generate_presigned_url(s3_bucket, s3_key)

                            # Send an email with the presigned URL to the recipient
                            recipient_email = log_exists["EMAIL_ID"]
                            email_status = send_email(recipient_email, presigned_url)

                            if "Email Error" in email_status:
                                update_data = {"lambda_status": "FAILED", "msg": email_status}
                            else:
                                update_data = {"lambda_status": "COMPLETED", "msg": email_status, "file_name": file_name_format}
                                
                            condition = "tm_log_id = %s"
                            update_record(conn, "RAC_FS_TM_LOGS", update_data, condition, log_id)
                            
                            return {
                                'statusCode': 200,
                                'body': json.dumps({"message": f"Lambda status updated to {current_status}. CSV file uploaded to S3. Email sent: {email_status}"})
                            }
                        else:
                            return {
                                'statusCode': 500,
                                'body': json.dumps({"message": "No records found in the database."})
                            }
                    else:
                        logger.info("Failed to update lambda status.")
                        return {
                            'statusCode': 500,
                            'body': json.dumps({"message": "Failed to update lambda status."})
                        }
                else:
                    return {
                            'statusCode': 500,
                            'body': json.dumps({"message": "No lambda with pending status."})
                        }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({"message": "Log ID not found in our records."})
            }

    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({"message": str(e)})
        }