import pymysql
import json
import logging
import boto3
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.message import EmailMessage
import os
import csv
from datetime import datetime
from sercret_manager import secretManager
secretDit = secretManager.get_value(os.getenv("AWS_SECRETS_MYSQL"))
s3_secretDit = secretManager.get_value(os.getenv("AWS_SECRETS_S3"))
s3KeyId = s3_secretDit["aws_access_key_id"]
s3AccessKey = s3_secretDit["aws_secret_access_key"]

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class DatabaseConnection:
    def __init__(self):
        self.host = secretDit["host"]
        self.username = secretDit["username"]
        self.password = secretDit["password"]
        self.db_name = secretDit["dbname"]
        self.port = int(secretDit["port"])
        
    def connect(self):
        try:
            connection = pymysql.connect(
                host=self.host,
                user=self.username,
                password=self.password,
                port=self.port,
                db=self.db_name,
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
            return connection
        except Exception as e:
            raise Exception(f"Error connecting to the database: {str(e)}")

def is_log_id_exists(connection, log_id):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM RAC_FS_TM_LOGS WHERE tm_log_id = %s", (log_id,))
            result = cursor.fetchone()
            return result
    except Exception as e:
        return None

def update_lambda_status(connection, log_id, status):
    try:
        with connection.cursor() as cursor:
            cursor.execute("UPDATE RAC_FS_TM_LOGS SET lambda_status = %s WHERE tm_log_id = %s", (status, log_id))
            connection.commit()
            return True
    except Exception as e:
        logger.error(f"Error updating lambda status: {str(e)}")
        return False
    
def update_record(connection, table_name, update_data, condition, log_id):
    try:
        with connection.cursor() as cursor:
            sql = f"UPDATE {table_name} SET "
            set_clause = ", ".join([f"{column} = %s" for column in update_data.keys()])
            sql += set_clause
            sql += f" WHERE {condition}"

            values = list(update_data.values())
            values.append(log_id)

            # Execute the SQL statement
            cursor.execute(sql, values)

            # Commit the transaction
            connection.commit()

            return True
    except Exception as e:
        logger.error(f"Error updating record in {table_name}: {str(e)}")
        return False
    
def fetch_records_from_database(connection, type=None, **kwargs):
    query = """
        SELECT 
            tab_fs_emp.EMPLOYEE_ID,
            tab_hr_tm.EMPLOYEE_NAME,
            tab_fs_emp.MANAGER_ID,
            tab_hr_tm.EMAIL,
            tab_hr_tm_1.EMPLOYEE_NAME as MANAGER_NAME,
            tab_hr_tm.RESOURCE_NUMBER,
            tab_fs_emp.LOCATION_CODE,
            tab_area.AREA_SHORT_NAME,
            tab_region.REGION_NAME,
            tab_team_type.TEAM_TYPE_NAME,
            tab_fs_emp.MANAGER_FLAG,
            tab_fs_emp.WORK_SHIFT,
            tab_fs_emp.ON_CALL,
            tab_fs_emp.ON_SITE,
            tab_fs_emp.DEDICATED,
            tab_fs_emp.DEDICATED_TO,
            tab_fs_emp.SERVICE_ADVANTAGE,
            tab_fs_emp.FS_STATUS,
            tab_fs_emp.SERVICE_START_DATE,
            tab_fs_emp.SERVICE_END_DATE,
            tab_fs_emp.RECORD_COMPLETE,
            tab_fs_emp.ADMIN_NOTES,
            tab_job_code.JOB_TITLE,
            tab_job_code.JOB_ADP_CODE,
            tab_job_code.JOB_TYPE,
            NULL CHANGE_NOTES,
            NULL CHANGE_EFFECTIVE_DATE,
            NULL REVIEW_DATE,
            NULL UPDARE_FLAG,
            tab_hr_tm.CONTINGENT_WORKER,
            tab_hr_tm.EBS_USER_NAME,
            tab_fs_emp.ABSENCE_START_DATE,
            tab_fs_emp.ABSENCE_END_DATE,
            tab_fs_emp.ACTUAL_RETURN_TO_WORK,
            tab_fs_emp.ALTERNATE_EMAIL,
            tab_fs_emp.BUSINESS_ORG,
            tab_fs_emp.PRODUCTION_PRINT,
            tab_hr_tm.HR_STATUS,
            tab_hr_tm.LAST_HIRE_DATE,
            tab_hr_tm.ACTUAL_TERMINATION_DATE,
            tab_hr_tm_1.RESOURCE_NUMBER as MANAGER_RESOURCE_NUMBER,
            tab_hr_tm.MANAGER_EMPLOYEE_ID as HR_MANAGER_EMPLOYEE_ID,
            tab_hr_tm.EMPLOYEE_ID as MANAGER_ID,
            CASE WHEN tab_hr_tm.MANAGER_EMPLOYEE_ID = tab_fs_emp.MANAGER_ID THEN 'Yes' ELSE 'No' END as MANAGER_MATCH_TO_HR,
            tab_hr_tm.JOB_TITLE as HR_JOB_TITLE,
            tab_hr_tm.JOB_CODE as HR_JOB_CODE,
            tab_hr_tm.JOB_ADP as HR_JOB_ADP,
            CASE 
                WHEN (
                    tab_hr_tm.JOB_TITLE != tab_job_code.JOB_TITLE
                    or tab_hr_tm.JOB_ADP != tab_job_code.JOB_ADP_CODE
                ) THEN 'No'
                ELSE 'Yes'
            END as JOB_MATCH_TO_HR,
            tab_hr_tm.AREA_SHORT as HR_AREA_SHORT,
            tab_hr_tm.REGION as HR_REGION,
            CASE 
                WHEN (
                    tab_hr_tm.AREA_SHORT != tab_area.AREA_SHORT_NAME
                    or tab_hr_tm.REGION != tab_region.REGION_NAME
                ) THEN 'No'
                ELSE 'Yes'
            END as REGION_AND_AREA_MATCH_TO_HR,
            tab_fs_emp.LAST_UPDATED_BY
        FROM
            RAC_FS_TM_EMPLOYEE_DTLS AS tab_fs_emp
                INNER JOIN
            RAC_HR_TM_EMPLOYEE_DTLS AS tab_hr_tm ON tab_fs_emp.EMPLOYEE_ID = tab_hr_tm.EMPLOYEE_ID
                LEFT JOIN
            RAC_HR_TM_EMPLOYEE_DTLS AS tab_hr_tm_1 ON tab_fs_emp.MANAGER_ID = tab_hr_tm_1.EMPLOYEE_ID
                LEFT JOIN
            RAC_FS_TM_AREA AS tab_area ON tab_area.AREA_ID = tab_fs_emp.AREA_ID
                LEFT JOIN
            RAC_FS_TM_REGION AS tab_region ON tab_region.REGION_ID = tab_area.REGION_ID
                LEFT JOIN
            RAC_FS_TM_TEAM_TYPE AS tab_team_type ON tab_team_type.TEAM_TYPE_ID = tab_fs_emp.TEAM_TYPE_ID
				LEFT JOIN
            RAC_FS_TM_JOB_CODE as tab_job_code on tab_job_code.JOB_ID = tab_fs_emp.JOB_ID
    """
    
    conditions = []

    if type == "export":
        if 'attribute1' in kwargs and kwargs['attribute1'] is not None:
            conditions.append(f"tab_hr_tm_1.EMPLOYEE_NAME LIKE '%{kwargs['attribute1']}%'")
        if 'attribute2' in kwargs and kwargs['attribute2'] is not None:
            conditions.append(f"""
                (
                    tab_hr_tm.RESOURCE_NUMBER LIKE '%{kwargs['attribute2']}%'
                    OR tab_hr_tm.EMPLOYEE_NAME LIKE '%{kwargs['attribute2']}%'
                    OR tab_hr_tm.EMPLOYEE_ID LIKE '%{kwargs['attribute2']}%'
                )
            """)

    if conditions:
        query += " WHERE " + " AND ".join(conditions)

    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            records = cursor.fetchall()
        return records
    except Exception as e:
        raise Exception(f"Error fetching records from the database: {str(e)}")
    

def fetch_location_records_from_database(connection):
    query = """
        SELECT 
            LOC_ID, 
            LOCATION_CODE, 
            DESCRIPTION, 
            ZIP_CODE,
            INACTIVE_DATE
        FROM
            RAC_FS_TM_LOC
    """

    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            records = cursor.fetchall()
        return records
    except Exception as e:
        raise Exception(f"Error fetching records from the database: {str(e)}")
    
def fetch_username_database(id):
    query = """
        SELECT RAC_FS_TM_GET_USER_NAME (%s) AS USER_NAME
    """

    connection = DatabaseConnection().connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute(query, (id,))
            username = cursor.fetchone()
            if username:
                return username
            else:
                return None
    except Exception as e:
        print(str(e), "Error fetching fetch_username_database")
        return None
    
def fetch_report_records_from_database(connection, type=None):
    query = """
        SELECT
            tab_fs_emp.EMPLOYEE_ID,
            tab_hr_tm.EMPLOYEE_NAME,
            tab_hr_tm.RESOURCE_NUMBER,
            tab_hrm_tm.EMPLOYEE_NAME AS MANAGER_NAME,
            tab_fs_emp.MANAGER_ID,
            tab_hr_tm.EMAIL,
            tab_hr_tm.AREA,
            tab_reg.REGION_NAME,
            tab_area.AREA_SHORT_NAME,
            tab_team.TEAM_TYPE_NAME,
            tab_job.JOB_TITLE,
            tab_job.JOB_ADP_CODE,
            tab_fs_emp.LOCATION_CODE,
            tab_fs_emp.MANAGER_FLAG,
            tab_fs_emp.WORK_SHIFT,
            tab_fs_emp.ON_CALL,
            tab_fs_emp.ON_SITE,
            tab_fs_emp.DEDICATED,
            tab_fs_emp.DEDICATED_TO,
            tab_fs_emp.SERVICE_ADVANTAGE,
            tab_fs_emp.FS_STATUS,
            tab_fs_emp.SERVICE_START_DATE,
            tab_fs_emp.SERVICE_END_DATE,
            tab_fs_emp.RECORD_COMPLETE,
            tab_hr_tm.LAST_HIRE_DATE,
            tab_hr_tm.ACTUAL_TERMINATION_DATE,
            tab_fs_emp.ABSENCE_START_DATE,
            tab_fs_emp.ABSENCE_END_DATE
        FROM
            RAC_FS_TM_EMPLOYEE_DTLS tab_fs_emp
        JOIN
            RAC_HR_TM_EMPLOYEE_DTLS tab_hr_tm ON tab_fs_emp.EMPLOYEE_ID = tab_hr_tm.EMPLOYEE_ID
        LEFT JOIN
            RAC_FS_TM_TEAM_TYPE tab_team ON tab_team.TEAM_TYPE_ID = tab_fs_emp.TEAM_TYPE_ID
        LEFT JOIN
            RAC_FS_TM_AREA tab_area ON tab_area.AREA_ID = tab_fs_emp.AREA_ID
        LEFT JOIN
            RAC_FS_TM_REGION tab_reg ON tab_reg.REGION_ID = tab_area.REGION_ID
        LEFT JOIN
            RAC_HR_TM_EMPLOYEE_DTLS tab_hrm_tm ON tab_hrm_tm.EMPLOYEE_ID = tab_fs_emp.MANAGER_ID
        LEFT JOIN
            RAC_FS_TM_JOB_CODE tab_job ON tab_job.JOB_ID = tab_fs_emp.JOB_ID
    """
    if type == "All":
        query += " WHERE 1=1"
    elif type == "Active":
        query += """
             WHERE (
                tab_hr_tm.ACTUAL_TERMINATION_DATE IS NULL
                OR tab_hr_tm.ACTUAL_TERMINATION_DATE > utc_date()
                OR tab_hr_tm.ACTUAL_TERMINATION_DATE = ''
            )
        """
    else:
        return None
    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            records = cursor.fetchall()
        return records
    except Exception as e:
        raise Exception(f"Error fetching records from the database: {str(e)}")

def get_area_dir_info(employee_id):
    query = """
        SELECT
            e.EMPLOYEE_ID,
            e.EMPLOYEE_NAME,
            e.RESOURCE_NUMBER,
            e.EMAIL
        FROM RAC_FS_TM_EMPLOYEE_DTLS a
        LEFT OUTER JOIN RAC_FS_TM_AREA c ON a.AREA_ID = c.AREA_ID
        LEFT OUTER JOIN RAC_HR_TM_EMPLOYEE_DTLS e ON c.AREA_DIR_EMP_ID = e.EMPLOYEE_ID
        WHERE a.EMPLOYEE_ID = %s 
    """

    connection = DatabaseConnection().connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute(query, (employee_id,))
            records = cursor.fetchone()
            if records:
                return records
            else:
                return None
    except Exception as e:
        print(str(e), "Error fetching get_area_dir_info from the database")
        logger.error('Error get_area_dir_info from the database: %s', str(e))

def get_area_fom_info(employee_id):
    query = """
        SELECT
            e.EMPLOYEE_ID,
            e.EMPLOYEE_NAME,
            e.RESOURCE_NUMBER,
            e.EMAIL
        FROM RAC_FS_TM_EMPLOYEE_DTLS a
        LEFT OUTER JOIN RAC_FS_TM_AREA c ON a.AREA_ID = c.AREA_ID
        LEFT OUTER JOIN RAC_HR_TM_EMPLOYEE_DTLS e ON c.AREA_FOM_EMP_ID = e.EMPLOYEE_ID
        WHERE a.EMPLOYEE_ID = %s 
    """

    connection = DatabaseConnection().connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute(query, (employee_id,))
            records = cursor.fetchone()
            if records:
                return records
            else:
                return None
    except Exception as e:
        print(str(e), "Error fetching get_area_fom_info from the database")
        logger.error('Error get_area_fom_info from the database: %s', str(e))

def get_region_dir_info(employee_id):
    query = """
        SELECT
            e.EMPLOYEE_ID,
            e.EMPLOYEE_NAME,
            e.RESOURCE_NUMBER,
            e.EMAIL
        FROM RAC_FS_TM_EMPLOYEE_DTLS a
        LEFT OUTER JOIN RAC_FS_TM_AREA c ON a.AREA_ID = c.AREA_ID
        LEFT OUTER JOIN RAC_FS_TM_REGION d ON d.REGION_ID = c.REGION_ID
        LEFT OUTER JOIN RAC_HR_TM_EMPLOYEE_DTLS e ON d.REGION_DIR_EMP_ID = e.EMPLOYEE_ID
        WHERE a.EMPLOYEE_ID = %s 
    """

    connection = DatabaseConnection().connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute(query, (employee_id,))
            records = cursor.fetchone()
            if records:
                return records
            else:
                return None
    except Exception as e:
        print(str(e), "Error fetching get_region_dir_info from the database")
        logger.error('Error get_region_dir_info from the database: %s', str(e))
    

def format_datetime(dt):
    if dt is not None and dt != '0000-00-00 00:00:00':
        if isinstance(dt, str):
            dt = datetime.strptime(dt, '%Y-%m-%d %H:%M:%S')
        return dt.strftime('%m-%d-%Y')
    return ''

def create_csv_from_records(records):
    csv_file = '/tmp/exported_data.csv'
    fieldnames = fieldnames = [
                    'Employee ID *', 'Resource Number', 'Record Complete *', 'Contingent Worker', 'Employee Name', 'Employee Email',
                    'Alternate Employee Email', 'EBS User Name', 'FS Status *', 'Business Org', 'Job Title *', 'Job Type',
                    'Manager Flag *', 'Job ADP Code *', 'Job Match to HR', 'Team Type *', 'OFSC Production Print', 'Region *',
                    'Area Short *', 'Location Code', 'Region and Area Match to HR', 'Manager Name', 'Manager Employee ID *',
                    'Manager Resource Number', 'Manager Match to HR', 'HR Status', 'Last Hire Date', 'Service Start Date (mm/dd/yyyy) *',
                    'Service End Date (mm/dd/yyyy)', 'Actual Termination Date', 'Absence Start Date (mm/dd/yyyy)', 'Absence End Date (mm/dd/yyyy)',
                    'Actual Return To Work (mm/dd/yyyy)', 'Work Shift (1st, 2nd, 3rd)', 'On Call', 'On Site', 'Dedicated', 'Dedicated To',
                    'Service Advantage', 'Region Dir Name', 'Region Dir Employee ID', 'Region Dir Resource Number', 'Region Dir Email',
                    'Area Dir Name', 'Area Dir Employee ID', 'Area Dir Resource Number', 'Area Dir Email', 'Area FOM Name',
                    'Area FOM Employee ID', 'Area FOM Resource Number', 'Area FOM Email', 'Change Note *',
                    'Change Effective Date (mm/dd/yyyy) *', 'Admin Notes', 'Review Date (mm/dd/yyyy)', 'Update Flag', 'Last Update By'
                ]


    with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for record in records:
            area_dir_info = get_area_dir_info(record.get('EMPLOYEE_ID'))
            area_fom_info = get_area_fom_info(record.get('EMPLOYEE_ID'))
            region_dir_info = get_region_dir_info(record.get('EMPLOYEE_ID'))
            username = fetch_username_database(record.get('LAST_UPDATED_BY'))
            writer.writerow({
                'Employee ID *': record.get('EMPLOYEE_ID', ''),
                'Resource Number': record.get('RESOURCE_NUMBER', ''),
                'Record Complete *': record.get('RECORD_COMPLETE', ''),
                'Contingent Worker': record.get('CONTINGENT_WORKER', ''),
                'Employee Name': record.get('EMPLOYEE_NAME', ''),
                'Employee Email': record.get('EMAIL', ''),
                'Alternate Employee Email': record.get('ALTERNATE_EMAIL', ''),
                'EBS User Name': record.get('EBS_USER_NAME', ''),
                'FS Status *': record.get('FS_STATUS', ''),
                'Business Org': record.get('BUSINESS_ORG', ''),
                'Job Title *': record.get('JOB_TITLE', ''),
                'Job Type': record.get('JOB_TYPE', ''),
                'Manager Flag *': record.get('MANAGER_FLAG', ''),
                'Job ADP Code *': record.get('JOB_ADP_CODE', ''),
                'Job Match to HR': record.get('JOB_MATCH_TO_HR', ''),
                'Team Type *': record.get('TEAM_TYPE_NAME', ''),
                'OFSC Production Print': record.get('PRODUCTION_PRINT', ''),
                'Region *': record.get('REGION_NAME', ''),
                'Area Short *': record.get('AREA_SHORT_NAME', ''),
                'Location Code': record.get('LOCATION_CODE', ''),
                'Region and Area Match to HR': record.get('REGION_AND_AREA_MATCH_TO_HR', ''),
                'Manager Name': record.get('MANAGER_NAME', ''),
                'Manager Employee ID *': record.get('MANAGER_ID', ''),
                'Manager Resource Number': record.get('MANAGER_RESOURCE_NUMBER', ''),
                'Manager Match to HR': record.get('MANAGER_MATCH_TO_HR', ''),
                'HR Status': record.get('HR_STATUS', ''),
                'Last Hire Date': format_datetime(record.get('LAST_HIRE_DATE')),
                'Service Start Date (mm/dd/yyyy) *': format_datetime(record.get('SERVICE_START_DATE')),
                'Service End Date (mm/dd/yyyy)': format_datetime(record.get('SERVICE_END_DATE')),
                'Actual Termination Date': format_datetime(record.get('ACTUAL_TERMINATION_DATE')),
                'Absence Start Date (mm/dd/yyyy)': format_datetime(record.get('ABSENCE_START_DATE')),
                'Absence End Date (mm/dd/yyyy)': format_datetime(record.get('ABSENCE_END_DATE')),
                'Actual Return To Work (mm/dd/yyyy)': format_datetime(record.get('ACTUAL_RETURN_TO_WORK')),
                'Work Shift (1st, 2nd, 3rd)': record.get('WORK_SHIFT', ''),
                'On Call': record.get('ON_CALL', ''),
                'On Site': record.get('ON_SITE', ''),
                'Dedicated': record.get('DEDICATED', ''),
                'Dedicated To': record.get('DEDICATED_TO', ''),
                'Service Advantage': record.get('SERVICE_ADVANTAGE', ''),
                'Region Dir Name': region_dir_info["EMPLOYEE_NAME"] if region_dir_info else '',
                'Region Dir Employee ID': region_dir_info["EMPLOYEE_ID"] if region_dir_info else '',
                'Region Dir Resource Number': region_dir_info["RESOURCE_NUMBER"] if region_dir_info else '',
                'Region Dir Email': region_dir_info["EMAIL"] if region_dir_info else '',
                'Area Dir Name': area_dir_info["EMPLOYEE_NAME"] if area_dir_info else '',
                'Area Dir Employee ID': area_dir_info["EMPLOYEE_ID"] if area_dir_info else '',
                'Area Dir Resource Number': area_dir_info["RESOURCE_NUMBER"] if area_dir_info else '',
                'Area Dir Email': area_dir_info["EMAIL"] if area_dir_info else '',
                'Area FOM Name': area_fom_info["EMPLOYEE_NAME"] if area_fom_info else '',
                'Area FOM Employee ID': area_fom_info["EMPLOYEE_ID"] if area_fom_info else '',
                'Area FOM Resource Number': area_fom_info["RESOURCE_NUMBER"] if area_fom_info else '',
                'Area FOM Email': area_fom_info["EMAIL"] if area_fom_info else '',
                'Change Note *': record.get('CHANGE_NOTES', ''),
                'Change Effective Date (mm/dd/yyyy) *': format_datetime(record.get('CHANGE_EFFECTIVE_DATE')),
                'Admin Notes': record.get('ADMIN_NOTES', ''),
                'Review Date (mm/dd/yyyy)': format_datetime(record.get('REVIEW_DATE')),
                'Update Flag': record.get('UPDATE_FLAG', ''),
                'Last Update By': username["USER_NAME"] if username else None
            })


    return csv_file

def create_csv_from_location_records(records):
    csv_file = '/tmp/location_data.csv'
    fieldnames = ['LOC ID', 'LOCATION CODE', 'DESCRIPTION', 'ZIP CODE', 'INACTIVE DATE']

    with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for record in records:
            writer.writerow({
                'LOC ID': record.get('LOC_ID', ''),
                'LOCATION CODE': record.get('LOCATION_CODE', ''),
                'DESCRIPTION': record.get('DESCRIPTION', ''),
                'ZIP CODE': record.get('ZIP_CODE', ''),
                'INACTIVE DATE': format_datetime(record.get('INACTIVE_DATE', ''))
            })

    return csv_file

def create_csv_from_report_records(records):
    csv_file = '/tmp/report_data.csv'
    fieldnames = [
                'Absence End Date', 'Absence Start Date', 'Actual Termination Date',
                'Area Short Name', 'Dedicated', 'Dedicated To', 'Email', 'Employee Id',
                'Employee Name', 'Fs Status', 'Job Adp Code', 'Job Title',
                'Last Hire Date', 'Location Code', 'Manager Flag', 'Manager Id',
                'Manager Name', 'On Call', 'On Site', 'Record Complete', 'Region Name',
                'Resource Number', 'Service Advantage', 'Service End Date',
                'Service Start Date', 'Team Type Name', 'Work Shift'
            ]


    with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for record in records:
            writer.writerow({
                'Absence End Date': format_datetime(record.get('ABSENCE_END_DATE', '')),
                'Absence Start Date': format_datetime(record.get('ABSENCE_START_DATE', '')),
                'Actual Termination Date': format_datetime(record.get('ACTUAL_TERMINATION_DATE', '')),
                'Area Short Name': record.get('AREA_SHORT_NAME', ''),
                'Dedicated': record.get('DEDICATED', ''),
                'Dedicated To': record.get('DEDICATED_TO', ''),
                'Email': record.get('EMAIL', ''),
                'Employee Id': record.get('EMPLOYEE_ID', ''),
                'Employee Name': record.get('EMPLOYEE_NAME', ''),
                'Fs Status': record.get('FS_STATUS', ''),
                'Job Adp Code': record.get('JOB_ADP_CODE', ''),
                'Job Title': record.get('JOB_TITLE', ''),
                'Last Hire Date': format_datetime(record.get('LAST_HIRE_DATE', '')),
                'Location Code': record.get('LOCATION_CODE', ''),
                'Manager Flag': record.get('MANAGER_FLAG', ''),
                'Manager Id': record.get('MANAGER_ID', ''),
                'Manager Name': record.get('MANAGER_NAME', ''),
                'On Call': record.get('ON_CALL', ''),
                'On Site': record.get('ON_SITE', ''),
                'Record Complete': record.get('RECORD_COMPLETE', ''),
                'Region Name': record.get('REGION_NAME', ''),
                'Resource Number': record.get('RESOURCE_NUMBER', ''),
                'Service Advantage': record.get('SERVICE_ADVANTAGE', ''),
                'Service End Date': format_datetime(record.get('SERVICE_END_DATE', '')),
                'Service Start Date': format_datetime(record.get('SERVICE_START_DATE', '')),
                'Team Type Name': record.get('TEAM_TYPE_NAME', ''),
                'Work Shift': record.get('WORK_SHIFT', '')
            })


    return csv_file
	
def fetch_log_records_from_database(connection):
    query = """
        SELECT NULL EMPLOYEE_ID,
                NULL RESOURCE_NUMBER,
                EMAIL_ID,
                FILE_NAME,
                LAMBDA_STATUS,
                MSG,
                TYPE,
                CREATION_DATE,
                RAC_FS_TM_GET_USER_NAME(CREATED_BY) as CREATED_BY 
            FROM RAC_FS_TM_LOGS
             WHERE TYPE in ('Bulk Import','home','LOG') 
        UNION
        SELECT EMPLOYEE_ID,
                RESOURCE_NUMBER,
                LOGIN EMAIL_ID,
                NULL FILE_NAME,
                NULL LAMBDA_STATUS,
                ERR_MSG MSG,
                SYNC_PROCESS TYPE,
                CREATION_DATE,
                RAC_FS_TM_GET_USER_NAME(CREATED_BY) as CREATED_BY 
            FROM RAC_FS_TM_SYNC_LOGS 
            where SYNC_PROCESS in ('HRMS','OFSC')
    """
    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            records = cursor.fetchall()
        return records
    except Exception as e:
        raise Exception(f"Error fetching records from the database: {str(e)}")
		
def create_csv_from_log_records(records):
    csv_file = '/tmp/log_data.csv'
    fieldnames = ['EMPLOYEE ID', 'RESOURCE NUMBER', 'EMAIL ID', 'FILE NAME', 'LAMBDA STATUS','MSG', 'TYPE', 'CREATION DATE', 'CREATED BY']

    with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for record in records:
            writer.writerow({
                'EMPLOYEE ID': record.get('EMPLOYEE_ID', ''),
                'RESOURCE NUMBER': record.get('RESOURCE_NUMBER', ''),
                'EMAIL ID': record.get('EMAIL_ID', ''),
                'FILE NAME': record.get('FILE_NAME', ''),
                'LAMBDA STATUS': record.get('LAMBDA_STATUS', ''),
                'MSG': record.get('MSG', ''),
                'TYPE': record.get('TYPE', ''),
                'CREATION DATE': format_datetime(record.get('CREATION_DATE', '')),
                'CREATED BY': record.get('CREATED_BY', '')
            })

    return csv_file


def upload_csv_to_s3(csv_file, s3_bucket, s3_key):
    s3_client = boto3.client('s3')
    try:
        s3_client.upload_file(csv_file, s3_bucket, s3_key)
        logger.info(f"Uploaded {csv_file} to S3 bucket {s3_bucket} with key {s3_key}")
    except Exception as e:
        logger.error(f"Error uploading {csv_file} to S3: {str(e)}")


def generate_presigned_url(s3_bucket, s3_key):
    s3_client = boto3.client('s3', region_name='us-east-1', aws_access_key_id=s3KeyId, aws_secret_access_key=s3AccessKey)
    url = s3_client.generate_presigned_url('get_object', Params={'Bucket': s3_bucket, 'Key': s3_key}, ExpiresIn=432000)
    return url

def send_email(recipient_email, download_link):
    try:
        smtp_server = os.environ.get("SMTP_SERVER")
        from_address = os.environ.get("FROM_ADDRESS")

        if not smtp_server or not from_address:
            raise ValueError("SMTP_SERVER or FROM_ADDRESS are not set.")

        subject = "Tech Master Data Export"
        body = f"Dear All,<br><br>Please download Bulk export sheet using below link and it's valid for 5 days.<br><br><table><tr>"
        
        body+=f"<tr><td><a href={download_link}>Download</a></td></tr>"
        body+= f"<tr></table><br>NOTE : This is a system generated email,***No reply required***<br><br>Thank you"
        msg = EmailMessage()
        msg.set_content(body)
        msg.add_alternative(body, subtype='html')
        msg['Subject'] = subject
        msg['From'] = from_address
        msg['To'] = recipient_email
        
        logger.info(recipient_email)
        smtp_client = smtplib.SMTP(smtp_server)
        smtp_client.sendmail(from_address, recipient_email, msg.as_string())
        smtp_client.quit()

        logger.info("Email sent successfully")

        return "Email Sent"

    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return "Email Error"

def lambda_handler(event, context):
    try:
        logger.info(f"Request payload is: {event}")
        log_id = event.get("log_id")

        db_connection = DatabaseConnection()
        conn = db_connection.connect()

        log_exists = is_log_id_exists(conn, log_id)

        if log_exists:
            with conn:
                request_type = log_exists["TYPE"]
                logger.info(f"request_type: {request_type}")
                if log_exists["LAMBDA_STATUS"] == "pending":
                    current_status = "STARTED"
                    if update_lambda_status(conn, log_id, current_status):
                        # Use the current timestamp for the file name
                        timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
                        if request_type == "location":
                            records = fetch_location_records_from_database(conn)
                            file_name_format = f"{timestamp}_techmaster_location.csv"
                        elif request_type == "LOG": 
                            records = fetch_log_records_from_database(conn)
                            file_name_format = f"{timestamp}_techmaster_log.csv"
                        elif request_type == "report": 
                            records = fetch_report_records_from_database(conn, type=log_exists['ATTRIBUTE1'])
                            file_name_format = f"{timestamp}_techmaster_report.csv"
                        elif request_type == "export":
                            ATTRIBUTE1 = log_exists['ATTRIBUTE1']
                            ATTRIBUTE2 = log_exists['ATTRIBUTE2']
                            records = fetch_records_from_database(conn, type=request_type, attribute1=ATTRIBUTE1, attribute2=ATTRIBUTE2)
                            file_name_format = f"{timestamp}_techmaster_filter_data_v1.csv"
                        else:
                            records = fetch_records_from_database(conn)
                            file_name_format = f"{timestamp}_techmaster_v1.csv"
                        if records:
                            
                            csv_filename = f"/tmp/{file_name_format}"

                            if request_type == "location":
                                csv_file_path = create_csv_from_location_records(records)
                            elif request_type == "LOG":
                                csv_file_path = create_csv_from_log_records(records)
                            elif request_type == "report":
                                csv_file_path = create_csv_from_report_records(records)
                            elif request_type == "export":
                                csv_file_path = create_csv_from_records(records)
                            else:
                                csv_file_path = create_csv_from_records(records)

                            s3_bucket = os.environ.get("S3_BUCKET")
                            s3_export_path = os.environ.get("S3_EXPORT_PATH")
                            s3_key = f"{s3_export_path}/{file_name_format}"
                            
                            upload_csv_to_s3(csv_file_path, s3_bucket, s3_key)

                            # Generate a presigned URL for the uploaded file
                            presigned_url = generate_presigned_url(s3_bucket, s3_key)

                            # Send an email with the presigned URL to the recipient
                            recipient_email = log_exists["EMAIL_ID"]
                            email_status = send_email(recipient_email, presigned_url)

                            if "Email Error" in email_status:
                                update_data = {"lambda_status": "FAILED", "msg": email_status}
                            else:
                                update_data = {"lambda_status": "COMPLETED", "msg": email_status, "file_name": file_name_format}
                                
                            condition = "tm_log_id = %s"
                            update_record(conn, "RAC_FS_TM_LOGS", update_data, condition, log_id)
                            
                            return {
                                'statusCode': 200,
                                'body': json.dumps({"message": f"Lambda status updated to {current_status}. CSV file uploaded to S3. Email sent: {email_status}"})
                            }
                        else:
                            return {
                                'statusCode': 500,
                                'body': json.dumps({"message": "No records found in the database."})
                            }
                    else:
                        logger.info("Failed to update lambda status.")
                        return {
                            'statusCode': 500,
                            'body': json.dumps({"message": "Failed to update lambda status."})
                        }
                else:
                    return {
                            'statusCode': 500,
                            'body': json.dumps({"message": "No lambda with pending status."})
                        }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({"message": "Log ID not found in our records."})
            }

    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({"message": str(e)})
        }