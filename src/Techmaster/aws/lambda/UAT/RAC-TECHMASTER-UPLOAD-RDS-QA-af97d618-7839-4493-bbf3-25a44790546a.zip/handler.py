import json
import logging
import boto3
from botocore.exceptions import NoCredentialsError
import pymysql
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.message import EmailMessage
import os
import csv
from sercret_manager import secretManager
secretDit = secretManager.get_value(os.getenv("AWS_SECRETS_MYSQL"))


logger = logging.getLogger()
logger.setLevel(logging.INFO)


class DatabaseConnection:
    def __init__(self):
        self.host = secretDit["host"]
        self.username = secretDit["username"]
        self.password = secretDit["password"]
        self.db_name = secretDit["dbname"]
        self.port = int(secretDit["port"])
        
        # self.host = os.environ.get("DB_HOST")
        # self.username = os.environ.get("DB_USER")
        # self.password = os.environ.get("DB_PASSWORD")
        # self.db_name = os.environ.get("DB_NAME")
        # self.port = int(os.environ.get("DB_PORT"))

    def connect(self):
        try:
            connection = pymysql.connect(
                host=self.host,
                user=self.username,
                password=self.password,
                port=self.port,
                db=self.db_name,
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
            return connection
        except Exception as e:
            raise Exception(f"Error connecting to the database: {str(e)}")


def is_log_id_exists(connection, log_id):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM RAC_FS_TM_LOGS WHERE tm_log_id = %s", (log_id))
            result = cursor.fetchone()
            return result
    except Exception as e:
        return None

def update_lambda_status(connection, log_id, status):
    try:
        with connection.cursor() as cursor:
            cursor.execute("UPDATE RAC_FS_TM_LOGS SET lambda_status = %s WHERE tm_log_id = %s", (status, log_id))
            connection.commit()
            return True
    except Exception as e:
        logger.error(f"Error updating lambda status: {str(e)}")
        return False

def check_file_exists(s3_bucket, s3_key):
    s3_client = boto3.client('s3')
    try:
        s3_client.head_object(Bucket=s3_bucket, Key=s3_key)
        return True
    except NoCredentialsError:
        return False
    except Exception as e:
        logger.error(f"Error checking file existence: {str(e)}")
        return False


def fetch_data_from_s3(s3_bucket, s3_key):
    s3_client = boto3.client('s3')
    try:
        #logger.info(f"s3_bucket: {s3_bucket}")
        #logger.info(f"s3_key: {s3_key}")
        response = s3_client.get_object(Bucket=s3_bucket, Key=s3_key)
        #logger.info(f"response: {response}")
        data = response['Body'].read().decode('utf-8').splitlines()
        logger.info(f"data: {data}")
        return data
    except Exception as e:
        logger.error(f"Error fetching data from S3: {str(e)}")
        return None
        
def insert_csv_records(connection,request_id,employee_id,employee_name,resource_number,
        manager_id,manager_flag,job_adp,job_type,job_title,job_family,location_code,zip_code,
        area,area_short,region,manager_name,team_type_name,service_start_date,service_end_date,
        work_shift,fs_status,cip,on_call,on_site,dedicated,dedicated_to,
        service_advantange,prodcution_type,record_completed,loc_id,ofsc_last_login,
        production_print,alternate_email,ofsc_status,effective_date,requested_by,
        last_edited_date,update_record,update_msg,change_note,admin_note,review_date,
        created_by):
        query = """
                INSERT INTO `RAC_FS_TM_BULK_IMPORT` (`REQUEST_ID`,\
                `EMPLOYEE_ID`,\
                `EMPLOYEE_NAME`,\
                `RESOURCE_NUMBER`,\
                `MANAGER_ID`,\
                `MANAGER_FLAG`,\
                `JOB_ADP`,\
                `JOB_TYPE`,\
                `JOB_TITLE`,\
                `JOB_FAMILY`,\
                `LOCATION_CODE`,\
                `ZIP_CODE`,\
                `AREA`,\
                `AREA_SHORT`,\
                `REGION`,\
                `MANAGER_NAME`,\
                `TEAM_TYPE_NAME`,\
                `SERVICE_START_DATE`,\
                `SERVICE_END_DATE`,\
                `WORK_SHIFT`,\
                `FS_STATUS`,\
                `CIP`,\
                `ON_CALL`,\
                `ON_SITE`,\
                `DEDICATED`,\
                `DEDICATED_TO`,\
                `SERVICE_ADVANTAGE`,\
                `PRODUCTION_TYPE`,\
                `RECORD_COMPLETE`,\
                `LOC_ID`,\
                `OFSC_LAST_LOGIN`,\
                `PRODUCTION_PRINT`,\
                `ALTERNATE_EMAIL`,\
                `OFSC_STATUS`,\
                `EFFECTIVE_DATE`,\
                `REQUESTED_BY`,\
                `LAST_EDITED_DATE`,\
                `UPDATE_RECORD`,\
                `UPDATE_MSG`,\
                `CHANGE_NOTES`,\
                `ADMIN_NOTES`,\
                `REVIEW_DATE`,\
                `CREATED_BY`)\
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """
        try:
            with connection.cursor() as cursor:    
                cursor.execute(query,(request_id,employee_id,employee_name,resource_number,
                        manager_id,manager_flag,job_adp,job_type,job_title,job_family,location_code,zip_code,
                        area,area_short,region,manager_name,team_type_name,service_start_date,service_end_date,
                        work_shift,fs_status,cip,on_call,on_site,dedicated,dedicated_to,
                        service_advantange,prodcution_type,record_completed,loc_id,ofsc_last_login,
                        production_print,alternate_email,ofsc_status,effective_date,requested_by,
                        last_edited_date,update_record,update_msg,change_note,admin_note,review_date,
                        created_by))
                connection.commit()
                return True
        except Exception as e:
            # logger.error(f"Error inserting records in table : {str(e)}")
            print('insert_csv_records: %s',str(e))
            return False


def update_record(connection, table_name, update_data, condition, log_id):
    try:
        with connection.cursor() as cursor:
            sql = f"UPDATE {table_name} SET "
            set_clause = ", ".join([f"{column} = %s" for column in update_data.keys()])
            sql += set_clause
            sql += f" WHERE {condition}"

            values = list(update_data.values())
            values.append(log_id)

            # Execute the SQL statement
            cursor.execute(sql, values)

            # Commit the transaction
            connection.commit()

            return True
    except Exception as e:
        logger.error(f"Error updating record in {table_name}: {str(e)}")
        return False

def call_stored_procedure(connection, log_id):
    try:
        with connection.cursor() as cursor:
            args = [log_id]
            logger.info(f"End1 call_stored_procedure: {log_id}")
            cursor.callproc('RAC_FS_TM_BULK_IMPORT_PROCEDURE', args)
            logger.info(f"End2 call_stored_procedure: {log_id}")
            cursor.execute()
            connection.commit()
            return true
    except Exception as e:
        logger.error(f"Error call_stored_procedure : {str(e)}")
        return "store Procedure Error"
        
def fetch_records_from_database(connection,log_id):
    query="""
        SELECT 
            EMPLOYEE_ID,
            EMPLOYEE_NAME,
            RESOURCE_NUMBER,
            CASE
                WHEN UPDATE_RECORD = 'E' THEN "ERROR"
                WHEN UPDATE_RECORD = 'S' THEN "SUCCESS"
                ELSE "PENDING"
            END As STATUS,
            UPDATE_MSG 
            FROM 
                RAC_FS_TM_BULK_IMPORT 
                WHERE REQUEST_ID=%s and UPDATE_RECORD in ('S','E','Y')
    """
    try:
        with connection.cursor() as cursor:
            cursor.execute(query,log_id)
            records = cursor.fetchall()
        return records
    except Exception as e:
        raise Exception(f"Error fetching records from the database: {str(e)}")


def create_csv_from_import_records(records):
    csv_file = '/tmp/bulk_import_data.csv'
    fieldnames = ['EMPLOYEE ID', 'EMPLOYEE NAME', 'RESOURCE NUMBER', 'STATUS', 'MESSAGE']

    with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for record in records:
            writer.writerow({
                'EMPLOYEE ID': record.get('EMPLOYEE_ID', ''),
                'EMPLOYEE NAME': record.get('EMPLOYEE_NAME', ''),
                'RESOURCE NUMBER': record.get('RESOURCE_NUMBER', ''),
                'STATUS': record.get('STATUS', ''),
                'MESSAGE': record.get('UPDATE_MSG', '')
            })

    return csv_file
    
def upload_csv_to_s3(csv_file, s3_bucket, s3_key):
    s3_client = boto3.client('s3')
    print('s3_bucket: %s' %(s3_bucket))
    print('s3_key: %s' %(s3_key))
    try:
        s3_client.upload_file(csv_file, s3_bucket, s3_key)
        logger.info(f"Uploaded {csv_file} to S3 bucket {s3_bucket} with key {s3_key}")
    except Exception as e:
        logger.error(f"Error uploading {csv_file} to S3: {str(e)}")

def generate_presigned_url(s3_bucket, s3_key):
    region = "us-east-1"
    serviceName = "s3"
    secretDit = secretManager.get_value(os.environ.get("AWS_SECRETS_S3"))
    #print('secretDit: %s' %(secretDit))
    s3KeyId = secretDit["aws_access_key_id"]
    s3AccessKey = secretDit["aws_secret_access_key"]
 
    s3_client = boto3.client(
                    service_name=serviceName,
                    region_name=region,
                    aws_access_key_id=s3KeyId,
                    aws_secret_access_key=s3AccessKey,
                )
    #s3_client = boto3.client('s3')
    url = s3_client.generate_presigned_url('get_object', Params={'Bucket': s3_bucket, 'Key': s3_key}, ExpiresIn=43200)
    return url

def send_email(recipient_email, download_link):
    try:
        smtp_server = os.environ.get("SMTP_SERVER")
        from_address = os.environ.get("FROM_ADDRESS")

        if not smtp_server or not from_address:
            raise ValueError("SMTP_SERVER or FROM_ADDRESS are not set.")

        subject = "Tech Master Data Import"
        body = f"Dear All,<br><br>Import file has been successfully uploaded, <br> Please download Bulk Import sheet using for how many records are success and not success,<br> below link and it's valid for 12 hours.<br><table><tr>"
        body+=f"<tr><td><a href={download_link}>Download</a></td></tr>"
        body+= f"<tr></table><br>NOTE : This is a system generated email,***No reply required***<br><br>Thank you"
        msg = EmailMessage()
        msg.set_content(body)
        msg.add_alternative(body, subtype='html')
        msg['Subject'] = subject
        msg['From'] = from_address
        msg['To'] = recipient_email
        
        logger.info(recipient_email)
        smtp_client = smtplib.SMTP(smtp_server)
        smtp_client.sendmail(from_address, recipient_email, msg.as_string())
        smtp_client.quit()

        logger.info("Email sent successfully")

        return "Email Sent"

    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return "Email Error"

def lambda_handler(event, context):
    try:
        logger.info(f"Request payload is: {event}")
        log_id = event.get("log_id")

        db_connection = DatabaseConnection()
        conn = db_connection.connect()

        log_exists = is_log_id_exists(conn, log_id)
        
        if log_exists:
            with conn:
                if log_exists["LAMBDA_STATUS"] == "pending":
                    current_status = "STARTED"
                    if update_lambda_status(conn, log_id, current_status):
                        # print(email_status)
                        fileName = log_exists["FILE_NAME"]
                        if fileName:
                            logger.info(f"fileName : {fileName}")
                            # Fetch data from S3
                            s3_bucket = os.environ.get("S3_BUCKET")
                            logger.info(f"s3_bucket : {s3_bucket}")
                            s3_import_path = os.environ.get("S_KEY")
                            s3_key = f"{s3_import_path}{fileName}"
                            logger.info(f"S3_Import File Path : {s3_key}")
                            data = fetch_data_from_s3(s3_bucket, s3_key) 
                            lines = csv.reader(data)
                            headers = next(lines)
                            print('headers: %s' %(headers))
                            for line in lines:
                                #print complete line
                                if line[7]:
                                    effective_date = '';
                                    effective_msg = '';
                                    # initializing format 
                                    format = "%m/%d/%Y"    
                                    effectivedateRes = True
                                    # using try-except to check for truth value
                                    if line[1]:
                                        try:
                                            effectivedateRes = bool(datetime.strptime(line[1], format))
                                        except ValueError:
                                            effectivedateRes = False 
                                    print('effectivedateRes: %s' %(effectivedateRes))
                                    if line[1]:
                                        if effectivedateRes:
                                            effective_date = datetime.strptime(line[1], "%m/%d/%Y").strftime('%Y-%m-%d')
                                            effective_msg
                                        else:    
                                            effective_date
                                            effective_msg='worng formate for change effective date'
                                    else:
                                        effective_date
                                        effective_msg
                                    print('effective_date: %s' %(effective_date)) 
                                    
                                    service_start_date = '';
                                    serviceStartDate_msg = '';
                                    serviceStartRes = True
                                    # using try-except to check for truth value
                                    if line[22]:
                                        try:
                                            serviceStartRes = bool(datetime.strptime(line[22], format))
                                        except ValueError:
                                            serviceStartRes = False 
                                    print('serviceStartRes: %s' %(serviceStartRes))         
                                    if line[22]:
                                        if serviceStartRes:
                                            service_start_date = datetime.strptime(line[22], "%m/%d/%Y").strftime('%Y-%m-%d')
                                            serviceStartDate_msg
                                        else:    
                                            service_start_date
                                            serviceStartDate_msg='worng formate for service start date'
                                    else:
                                        service_start_date
                                        serviceStartDate_msg
                                    print('service_start_date: %s' %(service_start_date)) 
                                    
                                    
                                    service_end_date = '';
                                    serviceEndDate_msg = '';
                                    serviceEndRes = True
                                    # using try-except to check for truth value
                                    if line[23]:
                                        try:
                                            serviceEndRes = bool(datetime.strptime(line[23], format))
                                        except ValueError:
                                            serviceEndRes = False 
                                    print('res: %s' %(serviceEndRes)) 
                                    if line[23]:
                                        if serviceEndRes:
                                            service_end_date = datetime.strptime(line[23], "%m/%d/%Y").strftime('%Y-%m-%d')
                                            serviceEndDate_msg
                                        else:    
                                            service_end_date
                                            serviceEndDate_msg='worng formate for service end date'
                                        print('service_end_date: %s' %(service_end_date)) 
                                    else:
                                        service_end_date
                                        serviceEndDate_msg
                                    
                                    review_date = '';
                                    reviewDate_msg = '';
                                    reviewDateRes = True
                                    # using try-except to check for truth value
                                    if line[27]:
                                        try:
                                            reviewDateRes = bool(datetime.strptime(line[27], format))
                                        except ValueError:
                                            reviewDateRes = False 
                                    print('reviewDateRes: %s' %(reviewDateRes))
                                    if line[27]:
                                        if reviewDateRes:
                                            review_date = datetime.strptime(line[27], "%m/%d/%Y").strftime('%Y-%m-%d')    
                                        else:    
                                            review_date
                                            reviewDate_msg='worng formate for review end date'
                                        print('review_date: %s' %(review_date))    
                                    else:
                                        review_date
                                        reviewDate_msg
                                    
                                    update_msg=''
                                    update_Flag=''
                                    if effective_msg :
                                        update_msg = effective_msg
                                        update_Flag='E'
                                        
                                    if serviceStartDate_msg :
                                        update_msg = serviceStartDate_msg
                                        update_Flag='E'
                                        
                                    if serviceEndDate_msg :
                                        update_msg = serviceEndDate_msg
                                        update_Flag='E'
                                        
                                    if reviewDate_msg :
                                        update_msg = reviewDate_msg
                                        update_Flag='E'
                                        
                                    if update_Flag:
                                        line[28]=update_Flag
                                    else:
                                        update_Flag=line[28]
                                    
                                    insert_csv_records(conn,log_id,
                                    line[7],
                                    line[9],
                                    line[8],
                                    line[6],
                                    line[25],
                                    line[13],
                                    line[12],
                                    line[11],
                                    '',
                                    line[4],
                                    '',
                                    '',
                                    line[3],
                                    line[2],
                                    line[5],
                                    line[14],
                                    service_start_date,
                                    service_end_date,
                                    line[15],
                                    line[21],
                                    '',
                                    line[16],
                                    line[17],
                                    line[18],
                                    line[19],
                                    line[20],
                                    '',
                                    line[24],
                                    '',
                                    '',
                                    '',
                                    line[10],
                                    '',
                                    effective_date,
                                    log_exists["CREATED_BY"],
                                    '',
                                    update_Flag,
                                    update_msg,
                                    line[0],
                                    line[26],
                                    review_date,
                                    log_exists["CREATED_BY"])
                            
                            call_stored_procedure(conn, log_id)
                            
                            timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S') 
                            
                            records = fetch_records_from_database(conn,log_id)
                            file_name_format = f"{timestamp}_techmaster.csv"
                            if records:
                                csv_file_path = create_csv_from_import_records(records)
                                print('csv_file_path: %s' %(csv_file_path)) 
                            
                                
                            s3_bucket = os.environ.get("S3_BUCKET")
                            s3_export_path = os.environ.get("S_KEY")
                            s3_key = f"{s3_export_path}{file_name_format}"
                            upload_csv_to_s3(csv_file_path, s3_bucket, s3_key)

                            # Generate a presigned URL for the uploaded file
                            presigned_url = generate_presigned_url(s3_bucket, s3_key)
                            
                            recipient_email = log_exists["EMAIL_ID"]
                            email_status = send_email(recipient_email,presigned_url)

                            print('email_status: %s' %(email_status))
                            if "Email Error" in email_status:
                                update_data = {"lambda_status": "FAILED", "msg": email_status}
                            else:
                                update_data = {"lambda_status": "COMPLETED", "msg": email_status}
                                
                            condition = "tm_log_id = %s"
                            update_record(conn, "RAC_FS_TM_LOGS", update_data, condition, log_id)
                            
                            return {
                                'statusCode': 200,
                                'body': json.dumps({"message": f"Lambda status updated to {current_status}. CSV file uploaded to S3. Email sent: {email_status}"})
                            }
                            
                        else:        
                            logger.info("File Not Found.")
                            update_data = {"lambda_status": "STARTED", "msg": "File Not Found."}
                            condition = "tm_log_id = %s"
                            update_record(conn, "RAC_FS_TM_LOGS", update_data, condition, log_id)
                            return {
                                'statusCode': 500,
                                'body': json.dumps({"message": "File Not Found."})
                            }
                   
                    else:
                        logger.info("Failed to update lambda status.")
                        return {
                            'statusCode': 500,
                            'body': json.dumps({"message": "Failed to update lambda status."})
                        }
                           
                else:
                    return {
                            'statusCode': 500,
                            'body': json.dumps({"message": "No lambda with pending status."})
                        }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({"message": "Log ID not found in our records."})
            }
        
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({"message": str(e)})
        }
